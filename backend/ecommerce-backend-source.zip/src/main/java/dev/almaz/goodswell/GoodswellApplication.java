package dev.almaz.goodswell;
import org.springframework.boot.SpringApplication;import org.springframework.boot.autoconfigure.SpringBootApplication;import org.springframework.cache.annotation.EnableCaching;
@SpringBootApplication @EnableCaching public class GoodswellApplication { public static void main(String[] args){SpringApplication.run(GoodswellApplication.class,args);} }
