package dev.almaz.goodswell.web;

import dev.almaz.goodswell.data.ProductRepository;
import dev.almaz.goodswell.domain.Product;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.util.List;

@RestController @RequestMapping("/api/products")
public class ProductController {
    private final ProductRepository products;
    public ProductController(ProductRepository products) { this.products = products; }
    public record NewProduct(@NotBlank @Size(max=140) String name,@NotNull @DecimalMin("0.01") BigDecimal price,@Min(0) @Max(1000000) int stock,@DecimalMin("0.0") @DecimalMax("100000.0") double averageDailySales,@Min(0) @Max(365) int supplierLeadDays,@Min(1) @Max(730) int targetCoverageDays) {}
    public record StockAdjustment(@Min(-1000000) @Max(1000000) int delta) {}
    @GetMapping public List<Product> list() { return products.findAll(); }
    @PostMapping public Product create(@RequestBody @Valid NewProduct input) { var product=new Product(input.name().trim(),input.price(),input.stock());product.setAverageDailySales(input.averageDailySales());product.setSupplierLeadDays(input.supplierLeadDays());product.setTargetCoverageDays(input.targetCoverageDays());return products.save(product); }
    @PatchMapping("/{id}/stock") @Transactional public Product adjustStock(@PathVariable Long id,@RequestBody @Valid StockAdjustment input) { var product=products.findByIdForUpdate(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Product not found"));int next=product.getStock()+input.delta();if(next<0)throw new ResponseStatusException(HttpStatus.CONFLICT,"Stock cannot go below zero");product.setStock(next);return product; }
}
