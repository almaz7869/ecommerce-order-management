package dev.almaz.goodswell.config;

import dev.almaz.goodswell.data.ProductRepository;
import dev.almaz.goodswell.domain.Product;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;

@Configuration
public class SeedData {
    @Bean CommandLineRunner seedProducts(ProductRepository products) {
        return args -> {
            if (products.count() == 0) {
                var backpack = new Product("Everyday Backpack", new BigDecimal("128.00"), 18);
                backpack.setAverageDailySales(1.6); backpack.setSupplierLeadDays(8); backpack.setTargetCoverageDays(18); products.save(backpack);
                var bottle = new Product("Studio Bottle", new BigDecimal("54.00"), 7);
                bottle.setAverageDailySales(2.4); bottle.setSupplierLeadDays(6); bottle.setTargetCoverageDays(18); products.save(bottle);
                var organizer = new Product("Desk Organizer", new BigDecimal("32.00"), 24);
                organizer.setAverageDailySales(0.8); organizer.setSupplierLeadDays(10); organizer.setTargetCoverageDays(20); products.save(organizer);
            }
        };
    }
}
