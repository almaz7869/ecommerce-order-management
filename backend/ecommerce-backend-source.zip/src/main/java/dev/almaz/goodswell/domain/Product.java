package dev.almaz.goodswell.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity @Table(name = "products")
public class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private String name;
    @Column(nullable = false, precision = 10, scale = 2) private BigDecimal price;
    @Column(nullable = false) private int stock;
    @Column(nullable = false) private double averageDailySales = 1.0;
    @Column(nullable = false) private int supplierLeadDays = 7;
    @Column(nullable = false) private int targetCoverageDays = 14;
    public Product() {}
    public Product(String name, BigDecimal price, int stock) { this.name = name; this.price = price; this.stock = stock; }
    public Long getId() { return id; }
    public String getName() { return name; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    public void setName(String name) { this.name = name; }
    public double getAverageDailySales() { return averageDailySales; }
    public void setAverageDailySales(double value) { this.averageDailySales = value; }
    public int getSupplierLeadDays() { return supplierLeadDays; }
    public void setSupplierLeadDays(int value) { this.supplierLeadDays = value; }
    public int getTargetCoverageDays() { return targetCoverageDays; }
    public void setTargetCoverageDays(int value) { this.targetCoverageDays = value; }
}
