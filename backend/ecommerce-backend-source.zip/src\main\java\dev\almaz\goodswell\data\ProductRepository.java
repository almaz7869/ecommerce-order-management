package dev.almaz.goodswell.data;

import dev.almaz.goodswell.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {}
