package dev.almaz.goodswell.web;

import dev.almaz.goodswell.data.ProductRepository;
import dev.almaz.goodswell.domain.Product;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("/api/products")
public class ProductController {
    private final ProductRepository products;
    public ProductController(ProductRepository products) { this.products = products; }
    @GetMapping @Cacheable("products") public List<Product> list() { return products.findAll(); }
}
