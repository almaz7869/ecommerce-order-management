package dev.almaz.goodswell.config;

import dev.almaz.goodswell.data.ProductRepository;
import dev.almaz.goodswell.domain.Product;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;

@Configuration
public class SeedData {
    @Bean CommandLineRunner seedProducts(ProductRepository products) {
        return args -> {
            if (products.count() == 0) {
                products.save(new Product("Everyday Backpack", new BigDecimal("128.00"), 18));
                products.save(new Product("Studio Bottle", new BigDecimal("54.00"), 7));
                products.save(new Product("Desk Organizer", new BigDecimal("32.00"), 24));
            }
        };
    }
}
